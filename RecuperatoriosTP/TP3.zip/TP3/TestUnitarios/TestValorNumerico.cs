﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Excepciones;
using Clases_Abstractas;
using Clases_Instanciables;

namespace TestUnitarios
{
    [TestClass]
    public class TestValorNumerico
    {
        /// <summary>
        /// Prueba Unitaria para verificar valores numéricos en el DNI del alumno
        /// </summary>
        [TestMethod]
        public void TestValidaDniNumerico()
        {
            Alumno a1 = new Alumno(1, "Juan", "Perez", "45698", Persona.ENacionalidad.Argentino, Universidad.EClases.Laboratorio);
            Assert.IsInstanceOfType(a1.DNI, typeof(int));
        }
    }
}
