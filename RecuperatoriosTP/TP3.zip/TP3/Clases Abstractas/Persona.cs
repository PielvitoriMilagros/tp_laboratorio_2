using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;


namespace Clases_Abstractas
{
    public abstract class Persona
    {
        /// <summary>
        /// Enumerado para la nacionalidad de la Persona
        /// </summary>
        public enum ENacionalidad
        {
            Argentino,
            Extranjero
        }

        #region Atributos

        private string apellido;
        private string nombre;
        private int dni;
        private ENacionalidad nacionalidad;

        #endregion


        #region Constructores
        
        /// <summary>
        /// Constructor por defecto
        /// </summary>
        public Persona()
        {
            this.apellido = "";
            this.nombre = "";
            this.dni = 0;
        }

        /// <summary>
        /// Constructor para Persona con parámetros
        /// </summary>
        /// <param name="nombre">Nombre de la persona</param>
        /// <param name="apellido">Apellido de la persona</param>
        /// <param name="nacionalidad">Nacionalidad de la persona</param>
        public Persona(string nombre, string apellido, ENacionalidad nacionalidad)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.nacionalidad = nacionalidad;
        }

        /// <summary>
        /// Constructor para la Persona con parámetros
        /// </summary>
        /// <param name="nombre">Nombre de la persona</param>
        /// <param name="apellido">Apellido de la persona</param>
        /// <param name="dni">Dni de la persona</param>
        /// <param name="nacionalidad">Nacionalidad de la persona</param>
        public Persona(string nombre, string apellido, int dni, ENacionalidad nacionalidad) : this(nombre, apellido, nacionalidad)
        {
            this.DNI = dni;
        }

        /// <summary>
        /// Constructor para la Persona, con parámetros
        /// </summary>
        /// <param name="nombre">Nombre de la persona</param>
        /// <param name="apellido">Apellido de la persona</param>
        /// <param name="dni">Dni de la persona</param>
        /// <param name="nacionalidad">Nacionalidad de la persona</param>
        public Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad) : this(nombre, apellido, nacionalidad)
        {
            this.StringToDNI = dni;
        }
        #endregion



        #region Propiedades

        /// <summary>
        /// Get y Set para nacionalidad de la persona
        /// </summary>
        public ENacionalidad Nacionalidad
        {
            get { return nacionalidad; }
            set { nacionalidad = value; }
        }
        /// <summary>
        /// Get y Set para nombre de la persona
        /// </summary>
        public string Nombre
        {
            get { return nombre; }
            set
            {
                nombre = ValidarNombreApellido(value);
            }
        }

        /// <summary>
        /// Get y Set para apellido de la persona
        /// </summary>
        public string Apellido
        {
            get { return apellido; }
            set
            {
                apellido = ValidarNombreApellido(value);
            }
        }

        /// <summary>
        /// Get y Set para dni de la persona, con validación
        /// </summary>
        public int DNI
        {
            get { return dni; }
            set
            {
                this.dni = ValidarDni(this.nacionalidad, value);
            }
        }

        /// <summary>
        /// Get y set para dni de la persona, con validación, en caso de recibir un string
        /// </summary>
        public string StringToDNI
        {
            set
            {
                this.dni = ValidarDni(this.nacionalidad, value);
            }
        }
        #endregion


        #region Métodos

        /// <summary>
        /// Valida el Dni enviado como entero
        /// </summary>
        /// <param name="nacionalidad">Nacionalidad de la persona</param>
        /// <param name="dato">Dni enviado de la persona</param>
        /// <returns>Dni validado según nacionalidad</returns>
        private int ValidarDni(ENacionalidad nacionalidad, int dato)
        {
            return ValidarDni(nacionalidad, dato.ToString());
        }

        /// <summary>
        /// Valida el Dni enviado como entero
        /// </summary>
        /// <param name="nacionalidad">Nacionalidad de la persona</param>
        /// <param name="dato">Dni enviado de la persona</param>
        /// <returns>Dni validado según nacionalidad</returns>
        private int ValidarDni(ENacionalidad nacionalidad, string dato)
        {
            int auxDni = 0;
            if (int.TryParse(dato, out auxDni) && auxDni > 0 && auxDni <= 99999999)
            {
                if (nacionalidad == ENacionalidad.Argentino && auxDni > 89999999)
                {
                    throw new NacionalidadInvalidaException("La nacionalidad no se condice con el número de DNI");
                }
                if (nacionalidad == ENacionalidad.Extranjero && auxDni < 90000000)
                {
                    throw new NacionalidadInvalidaException("La nacionalidad no se condice con el número de DNI");
                }
            }
            else
            {
                throw new DniInvalidoException();
            }
            return auxDni;
        }

        /// <summary>
        /// Valida el nombre y apellido enviado  de la persona
        /// </summary>
        /// <param name="dato">Nombre o Apellido enviado  de la persona</param>
        /// <returns>Nombre o Apellido validados</returns>
        private static string ValidarNombreApellido(string dato)
        {
            if (dato.All(char.IsLetter))
                return dato;
            return "";
        }

        /// <summary>
        /// Sobrecarga del método ToString
        /// </summary>
        /// <returns>Datos de la persona</returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("NOMBRE COMPLETO: " + this.apellido + ", " + this.nombre);
            sb.AppendLine("NACIONALIDAD: " + this.nacionalidad);

            return sb.ToString();
        }

        #endregion

    }
}
