﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases_Abstractas
{
    public abstract class Universitario : Persona
    {

        #region Atributos

        private int legajo;

        #endregion


        #region Constructores

        /// <summary>
        /// Constructor por defecto
        /// </summary>
        public Universitario()
        {
            this.legajo = 0;
        }

        /// <summary>
        /// Constructor con parámetros
        /// </summary>
        /// <param name="legajo">Legajo del universitario</param>
        /// <param name="nombre">Nombre del universitario</param>
        /// <param name="apellido">Apellido del universitario</param>
        /// <param name="dni">Dni del universitario</param>
        /// <param name="nacionalidad">Nacionalidad del universitario</param>
        public Universitario(int legajo, string nombre, string apellido, string dni, ENacionalidad nacionalidad) : base(nombre, apellido, dni, nacionalidad)
        {
            this.legajo = legajo;
        }
        #endregion


        #region Métodos

        /// <summary>
        /// Sobrecarga del operador ==
        /// </summary>
        /// <param name="pg1">Universitario para comparar</param>
        /// <param name="pg2">Universitario para comparar</param>
        /// <returns>True si son iguales, False si no lo son</returns>
        public static bool operator ==(Universitario pg1, Universitario pg2)
        {
            if (pg1.GetType() == pg2.GetType() && (pg1.legajo == pg2.legajo || pg1.DNI == pg2.DNI))
                return true;
            return false;
        }

        /// <summary>
        /// Sobrecarga del operador !=
        /// </summary>
        /// <param name="pg1">Universitario para comparar</param>
        /// <param name="pg2">Universitario para comparar</param>
        /// <returns>True si son distintos, False si no lo son</returns>
        public static bool operator !=(Universitario pg1, Universitario pg2)
        {
            return !(pg1 == pg2);
        }

        /// <summary>
        /// Sobrecarga del Equals
        /// </summary>
        /// <param name="obj">Objeto a comparar</param>
        /// <returns>True si es un Universitario, False si no lo es</returns>
        public override bool Equals(object obj)
        {
            if (obj is Universitario)
                return true;
            else
                return false;
        }

        /// <summary>
        /// Mostrar los datos del Universitario
        /// </summary>
        /// <returns>Datos del universitario</returns>
        protected virtual string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(base.ToString());
            sb.AppendLine("LEGAJO NÚMERO: " + this.legajo);

            return sb.ToString();
        }
        #endregion


        #region Método Abstracto

        /// <summary>
        /// Analiza si el universitario participa de la clase
        /// </summary>
        /// <returns>Clases en las que participa el universitario</returns>
        protected abstract string ParticiparEnClase();


        #endregion


    }
}
