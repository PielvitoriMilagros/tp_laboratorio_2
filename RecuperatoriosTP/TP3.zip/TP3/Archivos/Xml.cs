using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using Excepciones;

namespace Archivos
{
    public class Xml<T> : IArchivo<T>
    {
        /// <summary>
        /// Guardar datos en un archivo .XML en el escritorio
        /// </summary>
        /// <param name="archivo">Nombre del archivo a generar</param>
        /// <param name="datos">Datos a guardar en el archivo</param>
        /// <returns></returns>
        public bool Guardar(string archivo, T datos)
        {
            bool retorno = false;
            StreamWriter streamWriter = null;
            try
            {
                streamWriter = new StreamWriter(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), archivo));
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
                xmlSerializer.Serialize(streamWriter, datos);
                retorno = true;
            }
            catch (Exception excepcion)
            {
                throw new ArchivosException(excepcion);
            }
            finally
            {
              if (streamWriter!= null)
                streamWriter.Close();
            }
            
            return retorno;
        }

        /// <summary>
        /// Leer un archivo .XML del escritorio
        /// </summary>
        /// <param name="archivo">Nombre del archivo a leer</param>
        /// <param name="datos">Variable para almacenar los datos le�dos</param>
        /// <returns></returns>
        public bool Leer(string archivo, out T datos)
        {
            bool retorno = false;
            XmlSerializer xmlSerializer;
            XmlTextReader lecturaArchivo;

            if (File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), archivo)))
            {
                xmlSerializer = new XmlSerializer(typeof(T));
                lecturaArchivo = new XmlTextReader(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), archivo));
                datos = (T)xmlSerializer.Deserialize(lecturaArchivo);
                lecturaArchivo.Close();
                retorno = true;
            }
            else
            {
                datos = default(T);
            }
            return retorno;

        }



    }
}
