﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Archivos
{
    public interface IArchivo<T>
    {
        /// <summary>
        /// Método a implementar de interfaz para guardar datos en un archivo
        /// </summary>
        /// <param name="archivo">Nombre del archivo donde guardar los datos</param>
        /// <param name="datos">datos a guardar en el archivo</param>
        /// <returns></returns>
        bool Guardar(string archivo, T datos);

        /// <summary>
        /// Método a implementar de interfaz para leer datos de un archivo
        /// </summary>
        /// <param name="archivo">Nombre del archivo del cual leer los datos</param>
        /// <param name="datos">Variable donde almacenar los datos leídos</param>
        /// <returns></returns>
        bool Leer(string archivo, out T datos);

    }
}
