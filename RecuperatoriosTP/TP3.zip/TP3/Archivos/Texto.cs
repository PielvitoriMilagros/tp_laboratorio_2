﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;

namespace Archivos
{
    public class Texto : IArchivo<string>
    {
        /// <summary>
        /// Guardar datos en un archivo .txt en el escritorio
        /// </summary>
        /// <param name="archivo">Nombre del archivo a generar</param>
        /// <param name="datos">Datos a guardar en el archivo</param>
        /// <returns></returns>
        public bool Guardar(string archivo, string datos)
        {
            bool retorno = false;
            StreamWriter auxArchivo = new StreamWriter(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop),archivo));
            if(!(ReferenceEquals(auxArchivo,null) || ReferenceEquals(datos,null) ))
            {
                auxArchivo.Write(datos);
                retorno = true;
            }
            else
            {
                throw new ArchivosException(new Exception());
            }
            auxArchivo.Close();

            return retorno;
        }


        /// <summary>
        /// Leer un archivo .txt del escritorio
        /// </summary>
        /// <param name="archivo">Nombre del archivo a leer</param>
        /// <param name="datos">Variable para almacenar los datos leídos</param>
        /// <returns></returns>
        public bool Leer(string archivo, out string datos)
        {
            bool retorno = false;
            StreamReader lector;

            if (File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), archivo)))
            {
                lector = new StreamReader(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), archivo));
                datos = lector.ReadToEnd();
                lector.Close();
                retorno = true;
            }
            else
                datos = "";
            
            return retorno;
        }
    }
}
