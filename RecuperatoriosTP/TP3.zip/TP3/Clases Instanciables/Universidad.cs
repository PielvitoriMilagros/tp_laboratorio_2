using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;
using Archivos;

namespace Clases_Instanciables
{
    public class Universidad
    {
        public enum EClases
        {
            Programacion,
            Laboratorio,
            Legislacion,
            SPD
        }

        #region Atributos

        private List<Alumno> alumnos;
        private List<Jornada> jornada;
        private List<Profesor> profesores;

        #endregion


        #region Propiedades
        /// <summary>
        /// Get y set para la Lista de alumnos
        /// </summary>
        public List<Alumno> Alumnos
        {
            get { return alumnos; }
            set { this.alumnos = value; }
        }

        /// <summary>
        /// Get y Set para la lista de Jornadas
        /// </summary>
        public List<Jornada> Jornadas
        {
            get { return jornada; }
            set { this.jornada = value; }
        }

        /// <summary>
        /// Get y Set para la lista de profesores
        /// </summary>
        public List<Profesor> Instructores
        {
            get { return profesores; }
            set { this.profesores = value; }
        }

        /// <summary>
        /// Get y set Indexador para las Jornadas
        /// </summary>
        /// <param name="i">N�mero de jornada</param>
        /// <returns>N�mero de jornada</returns>
        public Jornada this[int i]
        {
            get
            {
                return this.jornada[i];
            }
            set { this.jornada[i] = value; }
        }
        #endregion

        #region M�todos

        /// <summary>
        /// Guarda archivo XML con los datos de la Universidad
        /// </summary>
        /// <param name="uni">Datos a guardar en el archivo</param>
        /// <returns>True si pudo guardar, False si no</returns>
        public static bool Guardar(Universidad uni)
        {
            Xml<Universidad> xml = new Xml<Universidad>();
            return xml.Guardar("Universidad.Xml", uni);
        }

        /// <summary>
        /// Lee archivo XML
        /// </summary>
        /// <returns>Datos del archivo le�do</returns>
        public static Universidad Leer()
        {
            Universidad universidadLeida;
            Xml<Universidad> xml = new Xml<Universidad>();
            xml.Leer("Universidad.Xml", out universidadLeida);
            return universidadLeida;
        }

        /// <summary>
        /// Muestra los datos de cada jornada de la universidad
        /// </summary>
        /// <param name="uni">Universidad</param>
        /// <returns>Datos de cada jornada</returns>
        private static string MostrarDatos(Universidad uni)
        {
            StringBuilder sb = new StringBuilder();

            foreach (Jornada jornada in uni.jornada)
            {
                sb.AppendLine(jornada.ToString());
            }

            return sb.ToString();
        }

        /// <summary>
        /// Sobrecarga del ToString
        /// </summary>
        /// <returns>Datos de la universidad con el que fue llamado</returns>
        public override string ToString()
        {
            return MostrarDatos(this);
        } 
        #endregion

        #region Constructores
        /// <summary>
        /// Constructor por defecto
        /// </summary>
        public Universidad()
        {
            this.alumnos = new List<Alumno>();
            this.jornada = new List<Jornada>();
            this.profesores = new List<Profesor>();
        }
        #endregion

        #region Operadores

        /// <summary>
        /// Sobrecarga del operador ==
        /// </summary>
        /// <param name="g">Universidad para comparar</param>
        /// <param name="a">Alumno para comparar</param>
        /// <returns>False si el alumno NO est� en la universidad</returns>
        public static bool operator ==(Universidad g, Alumno a)
        {
            foreach (Alumno auxAlumno in g.alumnos)
            {
                if (auxAlumno == a)
                    throw new AlumnoRepetidoException();
            }
            return false;
        }

        /// <summary>
        /// Sobrecarga del operador ==
        /// </summary>
        /// <param name="g">Universidad para comaprar</param>
        /// <param name="i">Instructor para comparar</param>
        /// <returns>True si el profesor est� en la universidad, False si no</returns>
        public static bool operator ==(Universidad g, Profesor i)
        {
            foreach (Jornada auxProfesor in g.jornada)
            {
                if (auxProfesor.Instructor == i)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Sobrecarga del operador ==
        /// </summary>
        /// <param name="g">Universidad para comparar</param>
        /// <param name="clase">Clase para comparar</param>
        /// <returns>Primer profesor en la universidad con la clase asignada</returns>
        public static Profesor operator ==(Universidad g, EClases clase)
        {
            foreach (Profesor auxProf in g.profesores)
            {
                if (auxProf == clase)
                    return auxProf;
            }
            throw new SinProfesorException();
        }

        /// <summary>
        /// Sobrecarga del operador !=
        /// </summary>
        /// <param name="g">Universidad para comparar</param>
        /// <param name="a">Alumno para comparar</param>
        /// <returns>True si el alumno NO est� en la universidad</returns>
        public static bool operator !=(Universidad g, Alumno a)
        {
            return !(g == a);
        }

        /// <summary>
        /// Sobrecarga del operador !=
        /// </summary>
        /// <param name="g">Universidad para comparar</param>
        /// <param name="i">Instructor para comparar</param>
        /// <returns>False si el profesor est� en la universidad, True si no</returns>

        public static bool operator !=(Universidad g, Profesor i)
        {
            return !(g == i);
        }

        /// <summary>
        /// Sobrecarga del operador !=
        /// </summary>
        /// <param name="g">Universidad a comparar</param>
        /// <param name="clase">Clases a comparar</param>
        /// <returns>Primer profesor que no puede dar la clase, o null en caso de no haber</returns>
        public static Profesor operator !=(Universidad g, EClases clase)
        {
            foreach (Jornada auxJornada in g.jornada)
            {
                if (auxJornada.Clase == clase)
                {
                    foreach (Profesor auxProf in g.profesores)
                    {
                        if (auxProf != clase)
                            return auxProf;
                    }
                }
            }
            return null;
        }

        /// <summary>
        /// Sobrecarga del operador + para agregar una clase si hay profesor asignado
        /// </summary>
        /// <param name="g">Universidad</param>
        /// <param name="clase">Clase</param>
        /// <returns>Universidad con clase agregada</returns>
        public static Universidad operator +(Universidad g, EClases clase)
        {
            Jornada nuevaJornada;
            if (g.profesores.Count == 0)
            {
                throw new SinProfesorException();
            }
            else
            {
                nuevaJornada = new Jornada(clase, g == clase);
                foreach (Alumno auxAlumno in g.alumnos)
                {
                    if (auxAlumno == clase)
                        nuevaJornada.Alumnos.Add(auxAlumno);
                }
                g.jornada.Add(nuevaJornada);

            }

            return g;
        }

        /// <summary>
        /// sobrecarga del operador +, agregar alumno a universidad 
        /// </summary>
        /// <param name="g">Universidad</param>
        /// <param name="a">Alumno</param>
        /// <returns>Universidad</returns>
        public static Universidad operator +(Universidad g, Alumno a)
        {
            if (ReferenceEquals(a, null))
                throw new NullReferenceException();

            if (g != a)
                g.alumnos.Add(a);

            return g;
        }

        /// <summary>
        /// Sobrecarga del operador +, agregar profesor a universidad si no est� repetido
        /// </summary>
        /// <param name="g">Universidad</param>
        /// <param name="i">Profesor</param>
        /// <returns>Universidad</returns>
        public static Universidad operator +(Universidad g, Profesor i)
        {
            if (g != i)
                g.profesores.Add(i);

            return g;
        }

        #endregion


    }
}
