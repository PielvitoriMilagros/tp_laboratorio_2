using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clases_Abstractas;

namespace Clases_Instanciables
{
    public sealed class Profesor : Universitario
    {
        #region Atributos
        private Queue<Universidad.EClases> clasesDelDia;
        private static Random random;

        #endregion

        #region Métodos

        /// <summary>
        /// Generar dos clases random según enumerado y agregarlas a la lista de clases del día del profesor
        /// </summary>
        private void _randomClases()
        {
            clasesDelDia = new Queue<Universidad.EClases>();
            clasesDelDia.Enqueue((Universidad.EClases)(random.Next(0, 3)));
            clasesDelDia.Enqueue((Universidad.EClases)(random.Next(0, 3)));
        }

        /// <summary>
        /// Mostrar datos del profesor
        /// </summary>
        /// <returns>Datos del profesor</returns>
        protected override string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(base.MostrarDatos());
            sb.AppendLine(this.ParticiparEnClase());

            return sb.ToString();
        }





        /// <summary>
        /// Implementación del método abstracto ParticiparEnClase
        /// </summary>
        /// <returns>Clases del día y las clases asignadas</returns>
        protected override string ParticiparEnClase()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("CLASES DEL DÍA:");
            if (this.clasesDelDia != null)
            {
                foreach (Universidad.EClases auxClase in this.clasesDelDia)
                {
                    sb.AppendLine(auxClase.ToString());
                }
            }

            return sb.ToString();
        }

        /// <summary>
        /// Sobrecarga de ToString
        /// </summary>
        /// <returns>Datos del profesor</returns>
        public override string ToString()
        {
            return this.MostrarDatos();
        } 
        #endregion

        #region Constructores
        /// <summary>
        /// Constructor por defecto del profesor
        /// </summary>
        public Profesor() : base()
        {
        }

        /// <summary>
        /// Constructor estático, inicializa el número random
        /// </summary>
        static Profesor()
        {
            Profesor.random = new Random();
        }
        /// <summary>
        /// Constructor con parámetros
        /// </summary>
        /// <param name="id">Id del profesor</param>
        /// <param name="nombre">Nombre del profesor</param>
        /// <param name="apellido">Apellido del profesor</param>
        /// <param name="dni">Dni del profesor</param>
        /// <param name="nacionalidad">Nacionalidad del profesor</param>
        public Profesor(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad) : base(id, nombre, apellido, dni, nacionalidad)
        {
            this.clasesDelDia = new Queue<Universidad.EClases>();
            this._randomClases();
        }
        #endregion


        #region Sobrecargas
        /// <summary>
        /// Sobrecarga del operador !=, profesor y clases
        /// </summary>
        /// <param name="i">Profesor</param>
        /// <param name="clase">Clase</param>
        /// <returns></returns>
        public static bool operator !=(Profesor i, Universidad.EClases clase)
        {
            return !(i == clase);
        }

        /// <summary>
        /// sobrecarga del operador ==, profesor y clase
        /// </summary>
        /// <param name="i"></param>
        /// <param name="clase"></param>
        /// <returns>True si el profesor tiene asignada la clase, false si no</returns>
        public static bool operator ==(Profesor i, Universidad.EClases clase)
        {
            foreach (Universidad.EClases auxClase in i.clasesDelDia)
            {
                if (auxClase == clase)
                    return true;
            }
            return false;
        } 
        #endregion


    }
}
