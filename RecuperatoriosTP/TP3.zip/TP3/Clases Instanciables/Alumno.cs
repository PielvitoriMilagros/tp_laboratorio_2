﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clases_Abstractas;

namespace Clases_Instanciables
{
    public sealed class Alumno : Universitario
    {
        public enum EEstadoCuenta
        {
            AlDia,
            Deudor,
            Becado
        }

        #region Atributos
        private EEstadoCuenta estadoCuenta;
        private Universidad.EClases claseQueToma;
        #endregion

        #region Constructores

        public Alumno()
        { }

        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, Universidad.EClases claseQueToma) : base(id, nombre, apellido, dni, nacionalidad)
        {
            this.claseQueToma = claseQueToma;
        }

        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, Universidad.EClases claseQueToma, EEstadoCuenta estadoCuenta) : this(id, nombre, apellido, dni, nacionalidad, claseQueToma)
        {
            this.estadoCuenta = estadoCuenta;
        }

        #endregion

        /// <summary>
        /// Muestra los datos del alumno, y la clase en la que participa
        /// </summary>
        /// <returns>Datos del alumno</returns>
        protected override string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();
            string estado="";
            switch (this.estadoCuenta)
            {
                case EEstadoCuenta.AlDia:
                    estado = "Cuota al día";
                    break;
                case EEstadoCuenta.Becado:
                    estado = "Becado";
                    break;
                case EEstadoCuenta.Deudor:
                    estado = "Alumno Deudor";
                    break;
                }


            sb.AppendLine(base.MostrarDatos());
            sb.AppendLine("ESTADO DE CUENTA: "+estado);
            sb.AppendLine(this.ParticiparEnClase());

            return sb.ToString();
        }

        /// <summary>
        /// Clase en la que participa el alumno
        /// </summary>
        /// <returns>Toma clase de y la clase en la que participa</returns>
        protected override string ParticiparEnClase()
        {
            return "TOMA CLASE DE " + this.claseQueToma;
        }

        /// <summary>
        /// Mostrar los datos del alumno
        /// </summary>
        /// <returns>Datos del alumno</returns>
        public override string ToString()
        {
            return this.MostrarDatos();
        }

        /// <summary>
        /// Verifica si el alumno es deudor y si ya está en la clase
        /// </summary>
        /// <param name="a">Alumno</param>
        /// <param name="clase">Clase</param>
        /// <returns>False si se cumplen esas condiciones, false si no</returns>
        public static bool operator ==(Alumno a, Universidad.EClases clase)
        {
            if (!(a != clase) && a.estadoCuenta != EEstadoCuenta.Deudor)
                return true;
            return false;
        }

        /// <summary>
        /// Verifica si el alumno toma la clase
        /// </summary>
        /// <param name="a">Alumno</param>
        /// <param name="clase">Clase</param>
        /// <returns>False si está en la clase, True si no</returns>
        public static bool operator !=(Alumno a, Universidad.EClases clase)
        {
            if (a.claseQueToma != clase)
                return true;
            return false;
        }

    }
}
