﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;

namespace TestsUnitarios
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TrackingIdRepetido()
        {
            Paquete nuevoPaquete = new Paquete("Avenida 123", "123456789");
            Correo c = new Correo();
            try
            {
                c += nuevoPaquete;
                c += nuevoPaquete;
            }
            catch (Exception exc)
            {
                Assert.IsInstanceOfType(exc, typeof(TrackingIdRepetidoException));
            }
        }

        [TestMethod]
        public void ListaDeCorreos()
        {
            Correo c = new Correo();
            Assert.IsNotNull(c.Paquetes);
        }

    }
}
