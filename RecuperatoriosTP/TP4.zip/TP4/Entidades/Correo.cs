﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Entidades
{
    public class Correo : IMostrar<List<Paquete>>
    {
        #region Atributos
        private List<Thread> mockPaquetes;
        private List<Paquete> paquetes;
        #endregion

        public List<Paquete> Paquetes
        {
            get { return paquetes; }
            set { paquetes = value; }
        }


        /// <summary>
        /// Constructor por defecto. Inicializa las listas, de paquetes y de hilos.
        /// </summary>
        public Correo()
        {
            this.mockPaquetes = new List<Thread>();
            this.paquetes = new List<Paquete>();
        }

        /// <summary>
        /// Finaliza la lista de hilos
        /// </summary>
        public void FinEntregas()
        {
            foreach (Thread auxHilo in this.mockPaquetes)
            {
                if (auxHilo.IsAlive)
                    auxHilo.Abort();
            }
        }

        /// <summary>
        /// Mostrar los datos del Correo y sus paquetes
        /// </summary>
        /// <param name="elementos">Correo</param>
        /// <returns>Detalle de cada paquete dentro del correo</returns>
        public string MostrarDatos(IMostrar<List<Paquete>> elementos)
        {
            List<Paquete> auxPaquetes;
            auxPaquetes = ((Correo)elementos).paquetes;
            StringBuilder sb = new StringBuilder();
            foreach (Paquete p in auxPaquetes)
            {
                sb.AppendLine(string.Format("{0} para {1} ({2})", p.TrackingID, p.DireccionEntrega, p.Estado.ToString()));
            }
            return sb.ToString();
        }

        public static Correo operator +(Correo c, Paquete p)
        {
            if (!ReferenceEquals(c.paquetes, null))
            {
                foreach (Paquete auxPaquete in c.paquetes)
                {
                    if (auxPaquete == p)
                    {
                        throw new TrackingIdRepetidoException("El Tracking ID " + auxPaquete.TrackingID + " ya figura en la lista de envios");
                    }
                }
                c.paquetes.Add(p);
                Thread thread = new Thread(p.MockCicloDeVida);
                c.mockPaquetes.Add(thread);
                thread.Start();
            }

            return c;
        }

    }
}
