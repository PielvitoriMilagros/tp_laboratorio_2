﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace MainCorreo
{
    public partial class FormPpal : Form
    {
        private Correo correo;

        public FormPpal()
        {
            InitializeComponent();
            this.correo = new Correo();
        }

        //BORRAR
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void FormPpal_Load(object sender, EventArgs e)
        {
            //            this.lstEstadoEntregado.Text = "";
            //          this.lstEstadoEnViaje.Text = "";
            //        this.lstEstadoIngresado.Text = "";
        }

        /// <summary>
        /// Actualiza los ListBox dependiendo de donde corresponde cada paquete
        /// </summary>
        private void ActualizarEstados()
        {
            this.lstEstadoIngresado.Items.Clear();
            this.lstEstadoEnViaje.Items.Clear();
            this.lstEstadoEntregado.Items.Clear();

            foreach (Paquete auxPaquete in this.correo.Paquetes)
            {
                if (auxPaquete.Estado == Paquete.EEstado.Ingresado)
                    this.lstEstadoIngresado.Items.Add(auxPaquete);
                if (auxPaquete.Estado == Paquete.EEstado.EnViaje)
                    this.lstEstadoEnViaje.Items.Add(auxPaquete);
                if (auxPaquete.Estado == Paquete.EEstado.Entregado)
                    this.lstEstadoEntregado.Items.Add(auxPaquete);
            }
        }

        /// <summary>
        /// Agrega un paquete al circuito de correo
        /// </summary>
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Paquete nuevoPaquete = new Paquete(this.txtDireccion.Text, this.mtxtTrackingID.Text);
            nuevoPaquete.InformaEstado += paq_InformaEstado;

            try
            {
                correo += nuevoPaquete;
                this.ActualizarEstados();
            }
            catch (TrackingIdRepetidoException exc)
            {
                MessageBox.Show(exc.Message);
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }

        }

        /// <summary>
        /// Muestra todos los paquetes
        /// </summary>
        private void btnMostrarTodos_Click(object sender, EventArgs e)
        {
            this.MostrarInformacion<List<Paquete>>((IMostrar<List<Paquete>>)correo);
        }

        /// <summary>
        /// Cierra todos los hilos antes de finalizar el programa
        /// </summary>
        private void FormPpal_FormClosing(object sender, FormClosedEventArgs e)
        {
            this.correo.FinEntregas();
        }

        /// <summary>
        /// Muestra la informacion del correo y la guarda en un txt
        /// </summary>
        private void MostrarInformacion<T>(IMostrar<T> elemento)
        {
            if (elemento != null)
            {
                this.rtbMostrar.Text = elemento.MostrarDatos(elemento);
                try
                {
                    this.rtbMostrar.Text.Guardar("Salida.txt");
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message);
                }
            }
        }

        /// <summary>
        /// Replica la actualizacion de estados en el formulario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void paq_InformaEstado(object sender, EventArgs e)
        {
            if (this.InvokeRequired)
            {
                Paquete.DelegadoEstado d = new Paquete.DelegadoEstado(paq_InformaEstado);
                this.Invoke(d, new object[] { sender, e });
            }
            else
            {
                this.ActualizarEstados();
            }
        }

        private void mostrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.MostrarInformacion<Paquete>((IMostrar<Paquete>)lstEstadoEntregado.SelectedItem);
        }

    }
}
