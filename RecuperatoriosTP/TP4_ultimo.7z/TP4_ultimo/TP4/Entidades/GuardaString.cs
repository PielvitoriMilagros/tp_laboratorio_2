﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Entidades
{
    public static class GuardaString
    {
        /// <summary>
        /// Metodo de extencion que guarda en un archivo txt en el escritorio los datos que se envian
        /// </summary>
        /// <param name="texto">Variable con la que llamar al metodo de extension, con el contenido que se guardara en el txt</param>
        /// <param name="archivo">Nombre del archivo a guardar</param>
        /// <returns>True si puede realizar la grabacion</returns>
        public static bool Guardar(this string texto, string archivo)
        {
            StreamWriter auxArchivo = null;
            bool retorno = false;
            try
            {
                auxArchivo = new StreamWriter(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop),archivo),true);
                if (!ReferenceEquals(auxArchivo,null))
                {
                    auxArchivo.WriteLine(texto);
                    retorno = true;
                }
                else
                {
                    throw (new Exception());
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (auxArchivo != null)
                    auxArchivo.Close();
            }

            return retorno;
        }
    }
}